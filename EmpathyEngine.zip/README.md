# Empathy Engine 🎙️

## Overview
The Empathy Engine is an AI-powered Text-to-Speech (TTS) system that detects the emotional tone of text and generates a voice output that reflects the detected emotion (happy, neutral, or sad).  
This helps make AI voice interactions sound more human and emotionally engaging.

## Features
- Detects emotion using TextBlob sentiment analysis.
- Modulates voice pitch, rate, and volume according to emotion.
- Outputs a playable `.mp3` or `.wav` audio file.
- Fully built in Python using open-source libraries.

## Setup Instructions
1. Install dependencies:
